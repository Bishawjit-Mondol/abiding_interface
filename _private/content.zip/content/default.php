<div class="about">
	<div class="wrap">
						<h1>No information about <span><?=$page?></span> is available.</h1>
	</div>
</div>
<?php
	include("inc/content/common_showcase.php");
?>
						<li><a href="index.php?page=home">Home</a></li>
						<li><a href="index.php?page=about">About</a></li>
						<li><a href="index.php?page=career">Career</a></li>
						<li><a href="index.php?page=contact">Contact</a></li>
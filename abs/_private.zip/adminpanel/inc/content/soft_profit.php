<?if($soft&&($logeduserlevel==1)){?>
<h1>Profit</h1>
<div id="bigmenu">
	<a href="index.php?page=soft_profit_daily">Daily Profit</a>
	<a href="index.php?page=soft_profit_datewise">Date-wise Profit</a>
</div>
<?}?>
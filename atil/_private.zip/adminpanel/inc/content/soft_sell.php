<h1>Sell</h1>
<div id="bigmenu">
	<a href="index.php?page=soft_sell_new">New</a>
	<a href="index.php?page=soft_sell_order">Orders</a>
	<a href="index.php?page=soft_sell_dues">Receivables</a>
	<a href="index.php?page=soft_sell_daily">Daily Sell </a>
	<a href="index.php?page=soft_sell_datewise">Date-wise Sell</a>
	<a href="index.php?page=soft_sell_search">Sell Search</a>
</div>
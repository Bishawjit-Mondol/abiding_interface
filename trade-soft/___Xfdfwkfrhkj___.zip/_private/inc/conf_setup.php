<?
    session_start();
    date_default_timezone_set('Asia/Dhaka');
    $company = file_get_contents("companyname.txt");
    $settingsfile = '___Xfdfwkfrhkj___/db.php';
    require $settingsfile;
    include("_private/inc/security.php");
?>

<div id = 'enc' style = 'display:none'><?=$encptid;?></div>
<div id = 'lang' style = 'display:none'><?=$lang;?></div>
<br/>
  <link rel="stylesheet" href="css/smoothness/jquery-ui.css">

  <script src="js/jquery-ui.js"></script>
  <script type='text/javascript' src='js/avro-v1.1.4.min.js'></script>
  <script type 'text/javascript' src = 'js/ajx.js'></script>   
  <script type 'text/javascript' src = 'js/page_element_control.js'></script>        
  <script type = 'text/javascript' charset="utf-8" src = 'js/content_loader.js'></script>

  <style>
  #resizable { width: 150px; height: 150px; padding: 0.5em; }
  #resizable h3 { text-align: center; margin: 0; }
  </style>

<div id = 'preview'>
</div>




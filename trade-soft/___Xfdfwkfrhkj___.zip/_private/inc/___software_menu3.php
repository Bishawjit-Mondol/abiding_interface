<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>          
<? /* Sugession menu Start  */ ?>


<!--
<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "বিক্রয়" : "Sales");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>

	<ul class="treeview-menu">

		<li class="treeview"  >
			<a href="#">
				<i class="fa fa-bar-chart-o"></i>
				<span><?=($lang ? "পি. পি. আর." : "PPR");?></span> 
				<i class="fa fa-angle-left pull-right"></i>
			</a>
			<ul class="treeview-menu search-result">

				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0031' data="cat_id=1&cat_name=PPR" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন অর্ডার" : "New Order");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0072' data="cat_id=1&cat_name=PPR" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "অর্ডারের তালিকা " : "Order List");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0147' data="cat_id=1&cat_name=PPR" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "চালান করুন " : "Make Chalan");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0148' data="cat_id=1&cat_name=PPR" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিল করুন " : "Make Bill");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0070' data="cat_id=1&cat_name=PPR" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিক্রয় ফেরত " : "Sales Return");?></span>
					</a>
				</li>
			</ul>
		</li>   
		<li class="treeview"  >
			<a href="#">
				<i class="fa fa-bar-chart-o"></i>
				<span><?=($lang ? "ইউ. পি. ভি. সি." : "uPVC");?></span>
				<i class="fa fa-angle-left pull-right"></i>
			</a>
			<ul class="treeview-menu search-result">

				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0031' data="cat_id=2&cat_name=uPVC" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন অর্ডার" : "New Order");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0072' data="cat_id=2&cat_name=uPVC" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "অর্ডারের তালিকা " : "Order List");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0147' data="cat_id=2&cat_name=uPVC" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "চালান করুন " : "Make Chalan");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0148' data="cat_id=2&cat_name=uPVC" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Make Bill");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0070' data="cat_id=2&cat_name=uPVC" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিক্রয় ফেরত " : "Sales Return");?></span>
					</a>
				</li>
			</ul>
		</li>
  
		<li>
			<a class = 'inactive page-loader box-entry link0024' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিক্রয় রিপোর্ট  " : "Sales Report");?></span>
			</a>
		</li>  
		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0219' href="#">
				<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  "বিক্রয় ফেরতের তথ্য" : " Sales return history " );?></span>
			</a>
		</li>
				
	</ul>
</li>   


-->





<!--






<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "পন্য মজুদ" : "Stock");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu">


		<li>

			<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry  link0802' data="cat_id=1&cat_name=PPR" href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পি,পি,অার, মজুদ" : "PPR Stock");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0802' data="cat_id=2&cat_name=uPVC" href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ইউ, পি, ভি, সি, মজুদ" : "uPVC Stock");?></span>
						</a>

					</li>

					<li>
						<a class = 'inactive page-loader box-entry  link0215' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "মজুদের লগ" : "Stock Log");?></span>
						</a>

					</li>
					<? if(0){ ?>
					<li>
						<a class = 'inactive page-loader box-entry  link0225' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "চাহিদার লগ" : "Stock demand Log");?></span>
						</a>

					</li>
					<? } ?>
				</ul>
			</li>   

			<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "পদক্ষেপ" : "Action");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0257' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "শোরুম যোগ করুন" : "Add Showroom");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0612' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পন্য যোগ করুন" : "Add Product");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0310' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পন্যের ধরন যোগ করুন" : "Add Product Catagory");?></span>
						</a>
					</li>

					<li>
						<a class = 'inactive page-loader box-entry link0004' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ইউনিট যোগ করুন" : "Add Unite");?></span>
						</a>

					</li>

					<li>
						<a class = 'inactive page-loader box-entry link0250' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পন্য সংশোধন করুন" : "Edit Product");?></span>
						</a>
					</li>

					<li>
						<a class = 'inactive page-loader box-entry link0305' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বারকোড প্রিন্ট করুন" : "Print Barcode");?></span>
						</a>
					</li>
 

				</ul>
			</li>   
		<li>
			<a class = 'inactive page-loader box-entry link0145' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পন্য সমন্বয়" : "Stock Adjustment");?></span>
			</a>

		</li>
		
		<li>
			<a class = 'inactive page-loader box-entry link0022' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পন্য স্থানান্তর" : "Product Transfer");?></span>
			</a>

		</li>


		</li>


	</ul>
</li>   











<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "ক্রেতা" : "Client");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0001' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন ক্রেতা" : "New Client");?></span>
			</a>

		</li>
		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0141' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্রেতার তালিকা " : "Client List");?></span>
			</a>

		</li>


		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry  link0217' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "খতিয়ান" : "Ledger");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0240' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যালেন্স" : "Balance");?></span>
						</a>

					</li>


				</ul>
		  

		</li>

	</ul>
</li>   










<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "বিক্রেতা" : "Supplier");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0000' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন বিক্রেতা" : "New Supplier");?></span>
			</a>

		</li>
		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0143' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিক্রেতার তালিকা " : "Supplier List");?></span>
			</a>

		</li>


		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry  link0218' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "খতিয়ান" : "Ledger");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0241' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যালেন্স" : "Balance");?></span>
						</a>

					</li>


				</ul>
		  

		</li>

	</ul>
</li>   








<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "কর্মকর্তা / কর্মচারী" : "Employee");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "পদক্ষেপ" : "Action");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0002' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "কর্মকর্তা / কর্মচারী যোগ করুন" : "Add Employee");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0300' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পাওনা অনুমোদন করুন" : "Add Payable");?></span>
						</a>

					</li>
				    

					<li>
						<a class = 'inactive page-loader box-entry link0003' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পদবী যোগ করুন" : "Add Post");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0304' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "কর্মকর্তা / কর্মচারী সংশোধন" : "Edit Employee");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0155' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "কর্মকর্তা / কর্মচারীর তালিকা" : "Employee List");?></span>
						</a>
					</li>
				</ul>
		</li>


		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0140' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "খতিয়ান" : "Ledger");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0256' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যালেন্স" : "Balance");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0223' href="#">
							<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  "কর্মচারীর বিক্রয় তথ্য " : "Emp. Sales Statement");?></span>
						</a>
					</li>
				</ul>
		</li>

	</ul>
</li>   


-->






<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "একাউন্টস" : "Accounts");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "নতুন লেনদেন" : "New Transaction");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0111' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্রেতার সাথে" : "With Client");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0017' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সরবরাহকারীর সাথে" : "With Supplier");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0019' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পরিচালকের সাথে" : "With Director");?></span>
						</a>

					</li>

					<li>
						<a class = 'inactive page-loader box-entry link0018' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "কর্মকর্তা / কর্মচারীদের সাথে" : "With Employee");?></span>
						</a>

					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0222' href="#">
							<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  "ইনসেন্টিভ গ্রহণকারীর সাথে" : "With incentive receiver");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0134' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "অন্যান্য খরচ" : "Other Expense");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0101' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ঋণের লেনদেন" : "Loan Transaction");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0105' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "অর্থ স্থানান্তর" : "Fund Transfer");?></span>
						</a>
					</li>
					

				</ul>
		</li>

		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">
					<li>
						<a class = 'inactive page-loader box-entry link0113' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "একাউন্ট লেজার" : "A/C Ledger");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0136' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "একাউন্ট ব্যালেন্স" : "A/C Balance");?></span>
						</a>
					</li>
					<? if($loan_solved){ ?>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0224' href="#">
							<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  "ঋণের তথ্য " : "Loan statement");?></span>
						</a>
					</li>
					<? } ?>
					<li>
						<a class = 'inactive page-loader box-entry link0118' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত চেকের তথ্য" : "Proposed Advance Cheque");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0119' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত ক্যাশ / ব্যাংক তথ্য" : "Proposed Cash / Bank Statement");?></span>
						</a>
					</li>
					<? if(0){ ?>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0123' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত গ্রহনের তথ্য" : "Proposed receive Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0122' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত প্রদানের তথ্য" : "Proposed Pay Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0121' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত ব্যাংক তথ্য" : "Proposed Bank Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0120' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত ক্যাশ তথ্য" : "Proposed Cash Statement");?></span>
						</a>
					</li>
					<? } ?>
					
				</ul>
		</li>


		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "পদক্ষেপ" : "Action");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0135' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "লেদেনের খাত যোগ করুন" : "Add Transaction Head");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0007' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্যাশ যোগ করুন" : "Add Cash");?></span>
						</a>

					</li>
					<li> 
						<a class = 'inactive page-loader box-entry link0008' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যাংক যোগ করুন" : "Add Bank");?></span>
						</a>
					</li>
					<li> 
						<a class = 'inactive page-loader box-entry link0112' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "চেকের পাতা যোগ করুন" : "Add Cheque Leaf");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0104' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ইনসেন্টিভ গ্রহীতা যোগ করুন" : "New Incentive Receiver");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0103' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ঋণ-প্রদানকারী যোগ করুন" : "Add New Lender");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0102' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন ঋণ যোগ করুন" : "Add New Loan");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0119' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "লেনদেন সংশোধন " : " Edit Transaction");?></span>
						</a>
					</li>

				</ul>
		</li>

	</ul>
</li>   


<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "ক্রেতা" : "Client");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>

	<ul class="treeview-menu search-result">



		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">


					<li>
						<a class = 'inactive page-loader box-entry  link0240' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যালেন্স" : "Balance");?></span>
						</a>

					</li>


				</ul>
		  

		</li>

	</ul>
</li>   



<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "বিক্রেতা" : "Supplier");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0000' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন বিক্রেতা" : "New Supplier");?></span>
			</a>

		</li>



		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">


					<li>
						<a class = 'inactive page-loader box-entry  link0241' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যালেন্স" : "Balance");?></span>
						</a>

					</li>


				</ul>
		  

		</li>

	</ul>
</li>   



<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "ক্রয়" : "Purchase");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu">

		<li>
			<a class = 'inactive page-loader box-entry link0151' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন ক্রয়" : "New Purchase");?></span>
			</a>

		</li>

		<li>
			<a class = 'inactive page-loader box-entry  link0068' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত ক্রয়" : "Proposed Purchase");?></span>
			</a>

		</li>	
		<li>
			<a class = 'inactive page-loader box-entry  link0157' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্রয় ফেরত" : "Purchase Return");?></span>
			</a>

		</li>
		<li>
			<a class = 'inactive page-loader box-entry  link0133' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সফলভাবে ক্রয়" : "Purchase Received");?></span>
			</a>
		</li>
		<li>
			<a class = 'inactive page-loader box-entry  link0158' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্রয় ফেরতের তথ্য" : "Purchase Return History");?></span>
			</a>
		</li>





		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry  link0177' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্রয় খতিয়ান" : "Purchase Ledger");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0178' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্রয় তথ্য" : "Purchase Statement");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0179' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "মোট ক্রয় তথ্য" : "Total Purchase Statement");?></span>
						</a>
					</li>			


				</ul>
		  

		</li>




	</ul>
</li>   



<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "ব্যাবহারকারী" : "User");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0253' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পাসওয়ার্ড সংশোধন করুন" : "Change Password");?></span>
			</a>

		</li>
	</ul>
</li>   





<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* Sugestion menu end  */ ?>

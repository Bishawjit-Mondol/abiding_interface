<h1>Soft</h1>
<div id="bigmenu">
<a href="index.php?page=soft_purchase">Purchase</a>
<a href="index.php?page=soft_sell">Sell</a>
<a href="index.php?page=soft_stock">Stock</a>
<a href="index.php?page=soft_revenue">Revenue</a>
<a href="index.php?page=soft_expenses">Expenses</a>
<?if($soft&&($logeduserlevel==1)){?>
<a href="index.php?page=soft_profit">Profit</a>
<?}?>
</div>
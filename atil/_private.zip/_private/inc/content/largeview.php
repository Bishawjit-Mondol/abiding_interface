<?php
	echo "<div id='sidemenu'>";
		include("_private/sidemenu.php");
	echo "</div>";
	display_single_image();
?>

<script type = 'text/javascript'>    
$("button#toolbarb1_<?=req('sub');?>" ).button({
      icons: {
	primary: "ui-icon-print"
      },
      text: false
});
$("button#toolbarb2_<?=req('sub');?>" ).button({
      icons: {
        primary: "ui-icon-pin-w"
      },
      text: false
});

$("button#toolbarb3_<?=req('sub');?>").button({
      icons: {
        primary: "ui-icon-closethick"
      },
      text: false
});    
</script>      


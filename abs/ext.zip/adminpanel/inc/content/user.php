<h1>User</h1>
<div id="bigmenu">
<a href="index.php?page=user_add">Add User</a>
<a href="index.php?page=user_status">Change User Status</a>
</div>
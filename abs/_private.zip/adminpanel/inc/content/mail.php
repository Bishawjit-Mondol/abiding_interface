<h1>Mail</h1>
<div id="bigmenu">
	<a href="index.php?page=mail_check">Check Mail</a>
	<a href="index.php?page=mail_set">Mail Settings</a>
</div>
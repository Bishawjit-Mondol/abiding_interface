<?php
	include("inc/content/common.php");
?>
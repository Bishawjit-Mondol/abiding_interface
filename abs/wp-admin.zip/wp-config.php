<?php
/**
 * The base configurations of the WordPress.
 *
 * This file has the following configurations: MySQL settings, Table Prefix,
 * Secret Keys, and ABSPATH. You can find more information by visiting
 * {@link https://codex.wordpress.org/Editing_wp-config.php Editing wp-config.php}
 * Codex page. You can get the MySQL settings from your web host.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'abidingg_abs');

/** MySQL database username */
define('DB_USER', 'abidingg_abs_u');

/** MySQL database password */
define('DB_PASSWORD', 'root123');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         'tNGT+0#n)0+0qdru(MDoZ`<?c]+IN2xQI/BEM9mN0+7LHp>NR5Q`lkn?%3$]j%R$');
define('SECURE_AUTH_KEY',  '+I;O|9wmySGWIvSL::<W+Ef9)R*l*8Eg#t^)GcZduceBFOG~Tp{&1hxiDUra1YQF');
define('LOGGED_IN_KEY',    '!R;z_]FfwCYw0W5.;F;F=9+(3=+5^H~`r>lXGfjWFD_|1v*+e$-fBe0o+-?l1N-W');
define('NONCE_KEY',        '-q):%a@/-@Z[H=yu$B;JFO=;aCy2;~[G(AX0C]Y!x?hC=k^XJw6%.5CbvxwTY) 3');
define('AUTH_SALT',        'cKpAo%jzD[ Vu#FAkJiV2h`{-+H&,]K;SBnWMbR+Y:u+G.wM_~zx^j*@o%BZA~:Z');
define('SECURE_AUTH_SALT', '#_K<2B.i}gk*~]VO6o.n,dV)kdG1?ZA|ljX|+|+]B5`S,9.Vg#@Syy/dPcdA.:+0');
define('LOGGED_IN_SALT',   ' u$hhX#,rmz21#/|c I[Y(}` .0h itoQWk%No^)vTBTqdMt}T#Xj-hZBdz2JHA%');
define('NONCE_SALT',       '9jK37fmYk@1;@L``!I-8ddRT&$slg`*nH2R-8Cd{Lodb3>T,O|,RYA yuW-$OB@2');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each a unique
 * prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'fahim_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
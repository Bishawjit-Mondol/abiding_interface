				<div class="about">
						<div class="wrap">
							<div class="panel-right">
									<br/>
									<p>
										<?=$home_intro?>
									</p>
							</div>
							<div class="clear"> </div>
						</div>
				</div>
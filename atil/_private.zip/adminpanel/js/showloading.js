
function showloading()
{
  document.getElementById("loading").id="showloading"; 
}
<?php
  echo "<h1>We have no info about ".$page."</h1>";
?>
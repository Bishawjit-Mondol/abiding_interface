				<div class="footer-grids">
					<div class="wrap">
						<div class="footer-grid">
							<h3>Our Units</h3>
							<?u_list('units');?>
						</div>
						<div class="footer-grid">
							<h3>Our Management</h3>
							<?u_list('management');?>
						</div>
						<div class="footer-grid">
							<h3>Career</h3>
							<?u_list('career');?>
						</div>
						<div class="footer-grid">
							<h3>Contact</h3>
							<?u_list('contact');?>
							<p class="copy-right" style='text-align:right;'>
								Copyright &#169; <a href="http://<?php echo $domain; ?>" target="_blank"><?php echo $companyname; ?></a>.
								<br/>Developed by <a href="http://www.uniquewebers.com/" target="_blank">Unique Webers Ltd.</a></p>
						</div>
						<div class="clear"> </div>
					</div>
				</div>
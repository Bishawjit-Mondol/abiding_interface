<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>          
<? /* Sayem menu start  */ ?>


<li class="treeview main-tree">
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "বিক্রয় খাতা" : "Sayem");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu">
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0123' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed receive Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0122' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed Pay Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0121' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed Bank Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0120' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed Cash Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0119' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed Cash / Bank Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0118' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Cheque Received on Cash");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0113' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Cash / Bank Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0112' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Add Cheque Leaf");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0008' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Add Bank Account");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0109' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Edit Purchase Return");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0108' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Purchase Return");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0110' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Edit Sales Return");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0070' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Sales Return");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0107' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Edit Purchase");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0106' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Edit Order");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0105' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Fund Transfer");?></span>
					</a>
					</li>
					<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0104' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "New Incentive Receiver");?></span>
					</a>
					</li>
					<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0103' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Add New Lender");?></span>
					</a>
					</li>
					<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0102' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Add New Loan");?></span>
					</a>
					</li>
					<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0150' href="#">  <? /* -- edit 0100 --*/ ?>
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Edit Transaction");?></span>
					</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0101' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Loan Transaction");?></span>
						</a>
					</li>		
	</ul>

</li>   


<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* Sayem menu end  */ ?>

<? /*sales book menu start  */ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<li class="treeview main-tree">
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?php echo($lang ? "সালমান" : "Salman");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu">

				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0219' href="#">
						<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  " বিক্রয়ক্রীত পণ্য ফেরতের পূর্বের তথ্য" : " Sales return history " );?></span>
					</a>
				</li>
				

				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0222' href="#">
						<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  " ইন্সেটিভ গ্রহণকারীর সাথে লেনদেন " : " Transaction With incentive receiver");?></span>
					</a>
				</li>
				
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0223' href="#">
						<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  " কর্মচারীর বিক্রয় তথ্য " : "Employee sales statement");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0224' href="#">
						<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  " কর্যের তথ্য " : "Loan statement");?></span>
					</a>
				</li>					
				
				
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0213' href="#">
						<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  " লেনদেনের বিল " : "Transection BILL / INVOICE");?></span>
					</a>
				</li>	

				
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0216' href="#">
						<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  " বিক্রয় চালান তথ্য " : "Sales chalan log");?></span>
					</a>
				</li>
				
	
	</ul>

</li>   




<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>          
<? /* Sugession menu Start  */ ?>


<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "বিক্রয়" : "Sales");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>

	<ul class="treeview-menu">

		<li class="treeview"  >
			<a href="#">
				<i class="fa fa-bar-chart-o"></i>
				<span><?=($lang ? "খুচরা বিক্রয়" : "PPR");?></span>
				<i class="fa fa-angle-left pull-right"></i>
			</a>
			<ul class="treeview-menu search-result">

				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0031' data="cat_id=4&cat_name=PPR" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "New Order");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0072' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Order List");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0147' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Make Chalan");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0148' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Make Bill");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0070' data="cat_id=4&cat_name=PPR" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Sales Return");?></span>
					</a>
				</li>
			</ul>
		</li>   
		<li class="treeview"  >
			<a href="#">
				<i class="fa fa-bar-chart-o"></i>
				<span><?=($lang ? "খুচরা বিক্রয়" : "uPVC");?></span>
				<i class="fa fa-angle-left pull-right"></i>
			</a>
			<ul class="treeview-menu search-result">

				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0031' data="cat_id=5&cat_name=uPVC" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "New Order");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0072' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Order List");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0147' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Make Chalan");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0148' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Make Bill");?></span>
					</a>
				</li>
				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0070' data="cat_id=5&cat_name=uPVC" href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Sales Return");?></span>
					</a>
				</li>
			</ul>
		</li>
  
		<li>
			<a class = 'inactive page-loader box-entry link0024' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিক্রয় ফেরৎ" : "Sales Report");?></span>
			</a>
		</li>  
		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0219' href="#">
				<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  " বিক্রয়ক্রীত পণ্য ফেরতের পূর্বের তথ্য" : " Sales return history " );?></span>
			</a>
		</li>
				
	</ul>
</li>   



<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>          
<? /* Sugession menu Start  */ ?>

<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "বিক্রয়" : "Old Sales");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu">


		<li class="treeview"  >
			<a href="#">
				<i class="fa fa-bar-chart-o"></i>
				<span><?=($lang ? "খুচরা বিক্রয়" : "Retail Sales");?></span>
				<i class="fa fa-angle-left pull-right"></i>
			</a>
			<ul class="treeview-menu search-result">

				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0031' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Normal Sales");?></span>
					</a>
				</li>
				<li>
					<a class = 'inactive page-loader box-entry  link2018' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বারকেডে বিক্রয়" : "Bar-Code Sales");?></span>
					</a>

				</li>
			</ul>
		</li>   

		<li class="treeview"  >
			<a href="#">
				<i class="fa fa-bar-chart-o"></i>
				<span><?=($lang ? "পাইকারী বিক্রয়" : "Whole Sales");?></span>
				<i class="fa fa-angle-left pull-right"></i>
			</a>
			<ul class="treeview-menu search-result">

				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0131' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সাধারন বিক্রয়" : "Normal Sales");?></span>
					</a>
				</li>
				<li>
					<a class = 'inactive page-loader box-entry link0138' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বারকেডে বিক্রয়" : "Bar-Code Sales");?></span>
					</a>

				</li>
			</ul>
		</li>   
		<li>
			<a class = 'inactive page-loader box-entry link0070' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিক্রয় ফেরৎ" : "Sales Return");?></span>
			</a>

		</li>
		<li class="treeview"  >
			<a href="#">
				<i class="fa fa-bar-chart-o"></i>
				<span><?=($lang ? "বিক্রয় রিপোর্ট" : "Sales Report");?></span>
				<i class="fa fa-angle-left pull-right"></i>
			</a>
			<ul class="treeview-menu search-result">

				<li class = 'menu-label'>
					<a class = 'inactive page-loader box-entry link0072' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত বিক্রয়" : "Proposed Sales");?></span>
					</a>
				</li>
				<li>
					<a class = 'inactive page-loader box-entry link0024' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিক্রয়ের রিপোর্ট" : "Sales Report");?></span>
					</a>
				</li>
				<li>
					<a class = 'inactive page-loader box-entry link0132' href="#">
						<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিক্রয় ফেরৎ রিপোর্ট" : "Sales Return Report");?></span>
					</a>
				</li>

			</ul>
		</li>   








	</ul>
</li>   



















<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "ক্রয়" : "Purchase");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu">

		<li>
			<a class = 'inactive page-loader box-entry link0030' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন ক্রয়" : "New Purchase");?></span>
			</a>

		</li>

		<li>
			<a class = 'inactive page-loader box-entry  link0068' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত ক্রয়" : "Proposed Purchase");?></span>
			</a>

		</li>		
		<li>
			<a class = 'inactive page-loader box-entry  link0133' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্রয়ের রিপোর্ট" : "Purchase Report");?></span>
			</a>

		</li>


	</ul>
</li>   











<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "পন্য মজুদ" : "Stock");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu">
		<li>
			<a class = 'inactive page-loader box-entry link0145' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পন্য সমন্বয়" : "Stock Adjustment");?></span>
			</a>

		</li>
		
		<li>
			<a class = 'inactive page-loader box-entry link0022' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পন্য স্থানান্তর" : "Product Transfer");?></span>
			</a>

		</li>
		<li>

			<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry  link0802' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বর্তমান মজুদ" : "Current Stock");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0215' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "মজুদের লগ" : "Stock Log");?></span>
						</a>

					</li>


				</ul>
			</li>   

			<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "পদক্ষেপ" : "Action");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0257' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "শোরুম যোগ করুন" : "Add Showroom");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0012' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পন্য যোগ" : "Add Product");?></span>
						</a>

					</li>

					<li>
						<a class = 'inactive page-loader box-entry link0004' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ইউনিট যেগ" : "Add Unite");?></span>
						</a>

					</li>

					<li>
						<a class = 'inactive page-loader box-entry link0250' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পন্য সংশেধন" : "Edit Product");?></span>
						</a>
					</li>

					<li>
						<a class = 'inactive page-loader box-entry link0305' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বারকোড প্রিন্ট" : "Print Barcode");?></span>
						</a>
					</li>


				</ul>
			</li>   


		</li>


	</ul>
</li>   







































<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "ক্রেতা" : "Client");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0001' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন ক্রেতা" : "New Client");?></span>
			</a>

		</li>
		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0141' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্রেতার তালিকা " : "Client List");?></span>
			</a>

		</li>


		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry  link0217' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "খতিয়ান" : "Ledger");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0240' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যালেন্স" : "Balance");?></span>
						</a>

					</li>


				</ul>
		  

		</li>

	</ul>
</li>   












<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "বিক্রেতা" : "Supplier");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0000' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন বিক্রেতা" : "New Supplier");?></span>
			</a>

		</li>
		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0143' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "বিক্রেতার তালিকা " : "Supplier List");?></span>
			</a>

		</li>


		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry  link0218' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "খতিয়ান" : "Ledger");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0241' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যালেন্স" : "Balance");?></span>
						</a>

					</li>


				</ul>
		  

		</li>

	</ul>
</li>   






<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "প্রবেশ / ত্যাগ" : "Entry / Exit");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "পদক্ষেপ" : "Action");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0228' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "যোগ" : "Add");?></span>
						</a>

					</li>


				</ul>
		  

		</li>


		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0229' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যাক্তির উপর" : "On Person");?></span>
						</a>

					</li>



				</ul>
		  

		</li>

	</ul>
</li>   



















<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "কর্মকর্তা / কর্মচারী" : "Employee");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "পদক্ষেপ" : "Action");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0002' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "যোগ" : "Add Employee");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0300' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পাওনা অনুমোদন" : "Add Payable");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0301' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পাওনার হিসাব করা" : "Generate Payable");?></span>
						</a>

					</li>

					<li>
						<a class = 'inactive page-loader box-entry link0003' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পদবী যোগ" : "Add Post");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry  link0304' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "কর্মকর্তা / কর্মচারী সংশোধন" : "Edit Employee");?></span>
						</a>
					</li>
				</ul>
		</li>


		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0140' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "খতিয়ান" : "Ledger");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0256' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যালেন্স" : "Balance");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0223' href="#">
							<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  " কর্মচারীর বিক্রয় তথ্য " : "Emp. Sales Statement");?></span>
						</a>
					</li>
				</ul>
		</li>

	</ul>
</li>   























<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "একাউন্টস" : "Accounts");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "নতুন লেনদেন" : "New Transaction");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0111' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ক্রেতার সাথে" : "With Client");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0017' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "সরবরাহকারীর সাথে" : "With Supplier");?></span>
						</a>

					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0019' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "পরিচালকের সাথে" : "With Director");?></span>
						</a>

					</li>

					<li>
						<a class = 'inactive page-loader box-entry link0018' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "কর্মকর্তা  / কর্মচারীদের সাথে" : "With Employee");?></span>
						</a>

					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0222' href="#">
							<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  "ইন্সেটিভ গ্রহণকারীর সাথে লেনদেন " : "With incentive receiver");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0134' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "অন্যান্য খরচ" : "Other Expense");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0101' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Loan Transaction");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0105' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "অর্থ স্থানান্তর" : "Fund Transfer");?></span>
						</a>
					</li>
					

				</ul>
		</li>

		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "রিপোর্ট" : "Report");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">
					<li>
						<a class = 'inactive page-loader box-entry link0113' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "একাউন্ট লেজার" : "A/C Ledger");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0136' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "একাউন্ট ব্যালেন্স" : "A/C Balance");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0224' href="#">
							<i class = 'fa fa-square-o'></i><span><?php echo($lang ?  " কর্যের তথ্য " : "Loan statement");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0118' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "প্রস্তাবিত চেকে লেনদেন" : "Proposed Advance Cheque");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0119' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed Cash / Bank Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0123' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed receive Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0122' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed Pay Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0121' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed Bank Statement");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0120' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Proposed Cash Statement");?></span>
						</a>
					</li>
					
				</ul>
		</li>


		<li class="treeview sugesstion-tree"  >
				<a href="#">
					<i class="fa fa-bar-chart-o"></i>
					<span><?=($lang ? "পদক্ষেপ" : "Action");?></span>
					<i class="fa fa-angle-left pull-right"></i>
				</a>
				<ul class="treeview-menu">

					<li>
						<a class = 'inactive page-loader box-entry link0135' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  " লেদেনের খাত যোগ করুন " : "Add Transaction Head");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0007' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "খতিয়ান" : "Add Cash");?></span>
						</a>

					</li>
					<li> 
						<a class = 'inactive page-loader box-entry link0008' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  " যোগ ব্যাংক " : "Add Bank");?></span>
						</a>
					</li>
					<li> 
						<a class = 'inactive page-loader box-entry link0112' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  " যোগ " : "Add Cheque Leaf");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0104' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "New Incentive Receiver");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0103' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Add New Lender");?></span>
						</a>
					</li>
					<li class = 'menu-label'>
						<a class = 'inactive page-loader box-entry link0102' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  "--" : "Add New Loan");?></span>
						</a>
					</li>
					<li>
						<a class = 'inactive page-loader box-entry link0119' href="#">
							<i class = 'fa fa-square-o'></i><span><?=($lang ?  " লেনদেন সংশোধন " : " Edit Transaction");?></span>
						</a>
					</li>

				</ul>
		</li>

	</ul>
</li>   





<li class="treeview treeview main-tree sugesstion-tree"  >
	<a href="#">
		<i class="fa fa-bar-chart-o"></i>
		<span><?=($lang ? "ব্যাবহারকারী" : "User");?></span>
		<i class="fa fa-angle-left pull-right"></i>
	</a>
	<ul class="treeview-menu search-result">

		<li class = 'menu-label'>
			<a class = 'inactive page-loader box-entry link0251' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "নতুন ব্যাবহারকারী" : "New User");?></span>
			</a>
			<a class = 'inactive page-loader box-entry  link0252' href="#">
				<i class = 'fa fa-square-o'></i><span><?=($lang ?  "ব্যাবহারকারীকে চিহ্নিত করা" : "Assign User");?></span>
			</a>

		</li>
	</ul>
</li>   



<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* ----------------------------------------------------------------------------*/ ?>
<? /* Sugestion menu end  */ ?>

<h1>Security</h1>
<div id="bigmenu">
	<a href="index.php?page=change_id">Change ID</a>
	<a href="index.php?page=change_pass">Change Password</a>
</div>
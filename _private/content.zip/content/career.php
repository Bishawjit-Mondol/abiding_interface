				<div class="about">
						<div class="testimonials">
							<div class="wrap">
								<div class="testimonial-head">
									<h1>Career Opportunity at <span><?=$companyname?></span></h1>
									<p>Only short listed candidates will be called for test and interview.</p>
								</div>	
								<?
									grid_images('career');
								?>
							</div>
						</div>
				</div>
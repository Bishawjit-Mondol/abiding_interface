<h1>Purchase</h1>
<div id="bigmenu">
			<a href="index.php?page=soft_purchase_new">New</a>
			<a href="index.php?page=soft_purchase_daily">Daily Purchase</a>
			<a href="index.php?page=soft_purchase_datewise">Date-wise Purchase</a>
			<a href="index.php?page=soft_purchase_search">Purchase Search</a>
</div>
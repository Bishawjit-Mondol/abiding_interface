<div class="wrapper row3">
<div id="container">
<?php
	echo "<div id='sidebar_1' class='sidebar one_quarter first'>";
		echo "<aside>";
			include("_private/sidemenu.php");
		echo "</aside>";
	echo"</div>";
	echo "<div class='three_quarter'>";
		display_single_image();
	echo"</div>";
?>
<div class="clear"></div>
</div>
</div>